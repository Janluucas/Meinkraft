package sereneseasons.api;

import net.minecraft.block.Block;

public class SSBlocks
{
    public static Block greenhouse_glass;
    
    public static Block[] season_sensors = new Block[4];
}
