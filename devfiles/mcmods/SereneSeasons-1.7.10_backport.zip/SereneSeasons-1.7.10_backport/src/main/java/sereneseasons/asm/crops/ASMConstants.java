
package sereneseasons.asm.crops;

public class ASMConstants
{
    public static final String Hooks = "sereneseasons.asm.crops.Hooks";
}