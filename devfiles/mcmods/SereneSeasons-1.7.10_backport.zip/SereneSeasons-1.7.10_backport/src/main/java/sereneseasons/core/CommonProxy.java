package sereneseasons.core;

import net.minecraft.block.Block;
import net.minecraft.item.Item;

public class CommonProxy
{
    public void registerRenderers() {}
    public void registerItemVariantModel(Item item, String name, int metadata) {}
    public void registerBlockSided(Block block) {}
    public void registerItemSided(Item item) {}
}