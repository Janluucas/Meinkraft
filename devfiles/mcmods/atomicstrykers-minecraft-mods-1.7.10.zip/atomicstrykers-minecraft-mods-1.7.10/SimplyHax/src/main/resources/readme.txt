
To install:

Simply put the .jar found in /mods/ into your .minecraft/mods/ folder!