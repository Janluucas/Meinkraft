package atomicstryker.battletowers.common;

public class CommonProxy
{
    public void preInit()
    {
        // NOOP
    }
    
    public void load()
    {
        // NOOP
    }
}
