package com.sirolf2009.necroapi;

import net.minecraft.util.ResourceLocation;

public interface ISaddleAble
{
    public ResourceLocation getSaddleTex();

    public int riderHeight();
}
