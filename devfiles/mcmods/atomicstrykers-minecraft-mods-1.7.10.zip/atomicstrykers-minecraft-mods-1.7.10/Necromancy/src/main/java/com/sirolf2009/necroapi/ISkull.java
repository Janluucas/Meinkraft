package com.sirolf2009.necroapi;

public interface ISkull
{
    public String getSkullModelTexture();

    public String getSkullIIconTexture();
}
