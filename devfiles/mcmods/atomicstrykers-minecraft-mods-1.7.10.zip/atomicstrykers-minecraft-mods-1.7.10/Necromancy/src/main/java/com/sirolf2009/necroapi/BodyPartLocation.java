package com.sirolf2009.necroapi;

public enum BodyPartLocation
{
    Head, Torso, ArmLeft, ArmRight, Legs
}
