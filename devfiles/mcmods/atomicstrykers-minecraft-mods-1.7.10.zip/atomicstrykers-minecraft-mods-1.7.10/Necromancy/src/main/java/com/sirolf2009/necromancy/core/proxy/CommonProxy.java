package com.sirolf2009.necromancy.core.proxy;

import net.minecraft.util.ResourceLocation;

public class CommonProxy
{

    public void preInit()
    {
        // NOOP
    }

    public void init()
    {
        // NOOP
    }

    public int addArmour(String path)
    {
        return 0;
    }

    public void spawnParticle(String name, double posX, double posY, double posZ, double motionX, double motionY, double motionZ)
    {
        // NOOP
    }

    public void bindTexture(ResourceLocation par1ResourceLocation)
    {
        // NOOP
    }

}