*The Betweenlands*
A large and expansive mod for Minecraft by Angry Pixel that adds a whole new dimension to the game, with new blocks, items, mobs, strucutres, biomes, sounds, mechanics and more.
