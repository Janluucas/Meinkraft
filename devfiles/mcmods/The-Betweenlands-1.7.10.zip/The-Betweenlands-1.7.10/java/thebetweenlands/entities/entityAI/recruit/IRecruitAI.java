package thebetweenlands.entities.entityAI.recruit;

public interface IRecruitAI {

}
