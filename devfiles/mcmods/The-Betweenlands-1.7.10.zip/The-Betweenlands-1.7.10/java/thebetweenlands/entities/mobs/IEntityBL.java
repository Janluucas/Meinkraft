package thebetweenlands.entities.mobs;

public interface IEntityBL {

    String pageName();
}
