package thebetweenlands.entities;

public interface WeedWoodBushUncollidableEntity {}
