package thebetweenlands.client.perspective;

public class PerspectiveThirdPersonFront extends PerspectiveThirdPerson {
	@Override
	protected final boolean isFrontFacing() {
		return true;
	}
}
