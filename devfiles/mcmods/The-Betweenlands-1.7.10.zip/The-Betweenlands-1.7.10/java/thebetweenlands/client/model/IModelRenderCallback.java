package thebetweenlands.client.model;

public interface IModelRenderCallback {
	void render(AdvancedModelRenderer advancedModelRenderer, float scale);
}
