package thebetweenlands.creativetabs;


public class BLCreativeTabs
{
	public static CreativeTabBetweenlands blocks = new TabBlocks();
	public static CreativeTabBetweenlands items = new TabItems();
	public static CreativeTabBetweenlands gears = new TabGears();
	public static CreativeTabBetweenlands specials = new TabSpecialItems();
	public static CreativeTabBetweenlands plants = new TabPlants();
	public static CreativeTabBetweenlands herbLore = new TabHerblore();
}
