GENERAL STUFF -
* Custom menu/GUI - swamp scene with fireflies/mobs/sound
* Custom loading screen with artwork of the mod
* Achievements

MORE CHANGES TO THE OVERWORLD -
* A rift in the sky or something like that
* Possibly a new mob or event
* A new ore used to coat tools, to prevent corrosion

TRIBE STUFF - 
*Shops - haggle system!
* Taxidermist - take mob heads, turn them into heads you can mount on the wall
* Inn of some kind
* Guy who cuts down trees
* Elder's Hut

MORE MOBS - 
* Shade
* Shallowbreath
* Floating Flamme
* Dirt Crawler
* Giant Fruit Bat
